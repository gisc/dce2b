Building a Second Brain with Agentic AI — interactive e-learning course
Audience: people who want to build their own second-brain AI agent
Duration: about 10 minutes  ·  Design: Gagne's Nine Events (G1-G9)

Open index.html in any modern browser. No server or internet needed.
Articulate-style player: title bar, lesson outline, Prev/Next seekbar, slide
transitions, light/dark theme toggle, and a text-size control (- A +).
Opens and closes with a "Karpathy's LLM Wiki, simplified" hero diagram.
overview.html is the course map (Map button); keep both files together.
Based on Andrej Karpathy's LLM Wiki pattern and Hermes Agent (Nous Research).
